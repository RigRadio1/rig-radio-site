// library.js — live-dot state, signed URLs, no-download
(function(){
  const step  = document.getElementById('step');
  const auth  = document.getElementById('auth');
  const fatal = document.getElementById('fatal');
  const list  = document.getElementById('list');
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const stop = (m) => { fatal.textContent = m; step.textContent = "Stopped"; };

  async function boot(){
    try{
      step.textContent = "Step 1/5: SDK";
      if (!window.supabase){ stop("Supabase SDK failed to load."); return; }

      step.textContent = "Step 2/5: Client";
      const _client = window.supabase.createClient(
        'https://tpzpeoqdpfwqumlsyhpx.supabase.co',
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRwenBlb3FkcGZ3cXVtbHN5aHB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcwMDM5NTEsImV4cCI6MjA3MjU3OTk1MX0.nP8W_G_N9GKucj6tlzyvSAOjhiqTBD-F564i0gNhp8E'
      );

      step.textContent = "Step 3/5: Session";
      const { data: s, error: se } = await _client.auth.getSession();
      if (se) console.warn("getSession error:", se);
      const session = s?.session || null;
      auth.textContent = session?.user ? ("Signed in: " + (session.user.email || "user")) : "Not signed in";

      step.textContent = "Step 4/5: Fetch";
      const { data, error } = await _client.from('tracks').select('*').order('created_at',{ascending:false}).limit(100);
      if (error){ stop("DB error: " + esc(error.message)); return; }

      step.textContent = "Step 5/5: Render";
      if (!data.length){
        list.innerHTML = '<div class="status">No tracks yet. <a class="rr-link" href="/submit">Submit one</a>.</div>';
        step.textContent = "Done"; return;
      }
function rowHTML(r){
  return `
    <article class="row" data-id="${r.id}">
      <div class="t"><img class="thumb" src="/banner.png" alt="cover"/></div>
      <div class="meta">
        <div class="title">${esc(r.title)||"(untitled)"}</div>
        <div>${esc(r.artist)||"(unknown)"} — <span class="pill">${esc(r.genre)||"—"}</span></div>
        ${r.notes ? `<div style="opacity:.75">${esc(r.notes)}</div>` : ``}

        <!-- Add/Remove from My Playlist (local only) -->
        <div class="plwrap">
          <button class="plbtn" data-pl="${r.id}">+ Add to My Playlist</button>
        </div>
      </div>
      <div class="p">
        <div class="live" aria-hidden="true"></div>
        <div class="msg">Preparing…</div>
      </div>
    </article>`;
}







      list.innerHTML = data.map(rowHTML).join("");
// --- Local playlist (safe, no backend changes) ---
const PL_KEY = "rr_playlist_ids";
const getPL = () => {
  try { return JSON.parse(localStorage.getItem(PL_KEY) || "[]"); }
  catch { return []; }
};
const setPL = (arr) => localStorage.setItem(PL_KEY, JSON.stringify(arr));
const inPL  = (id) => getPL().includes(id);

const togglePL = (id) => {
  let arr = getPL();
  const i = arr.indexOf(id);

  if (i > -1) {
    // If already in playlist → remove
    arr.splice(i, 1);
  } else {
    // Add new, but cap at 10
    if (arr.length >= 10) {
      alert("Free accounts can only have 10 songs in their playlist.");
      return arr;
    }
    arr.push(id);
  }

  setPL(arr);
  return arr;
};


// Initialize buttons
for (const r of data){
  const btn = document.querySelector(`button.plbtn[data-pl="${r.id}"]`);
  if (!btn) continue;
  const render = () => {
    const on = inPL(r.id);
    btn.classList.toggle("in", on);
    btn.textContent = on ? "✓ In My Playlist — Remove" : "+ Add to My Playlist";
  };
  render();
  btn.addEventListener("click", () => { togglePL(r.id); render(); });
}


      async function sign(path, seconds=3600){
        try{
          if(!path) return { url:null, err:"no path" };
          const { data, error } = await _client.storage.from('tracks').createSignedUrl(path, seconds);
          if (error) return { url:null, err:error.message };
          return { url:data.signedUrl, err:null };
        }catch(e){ return { url:null, err:e?.message || "sign error" }; }
      }

      for (const r of data){
        const card = document.querySelector(`.row[data-id="${r.id}"]`);
        const thumbWrap = card.querySelector('.t');
        const pane = card.querySelector('.p');
        const msg = pane.querySelector('.msg');

        // Cover (images only)
        if (r.cover_path){
          const { url } = await sign(r.cover_path);
          if (url) thumbWrap.innerHTML = `<img class="thumb" src="${url}" alt="cover"/>`;
        } else if (r.cover_url){
          thumbWrap.innerHTML = `<img class="thumb" src="${esc(r.cover_url)}" alt="cover" onerror="this.src='/banner.png'"/>`;
        }

        // Require auth to sign audio
        if (!session?.user){ msg.textContent="Sign in to play"; msg.style.color="#f66"; continue; }
        if (!r.track_path){ msg.textContent="Audio missing";   msg.style.color="#f66"; continue; }

        const { url: audioUrl, err } = await sign(r.track_path);
        if (err || !audioUrl){ msg.textContent = "Audio error: " + esc(err); msg.style.color="#f66"; continue; }

        // Build player with no-download UI
        pane.innerHTML =
          `<div class="live" aria-hidden="true"></div>
           <audio controls preload="none" src="${audioUrl}"
                  controlsList="nodownload noplaybackrate"
                  disablepictureinpicture
                  oncontextmenu="return false"></audio>`;
const audio = pane.querySelector('audio');
const live  = pane.querySelector('.live');
const setLive = (on)=> live.classList.toggle('on', !!on);
setLive(false); // ensure OFF initially

// When this audio starts, pause all other players on the page
audio.addEventListener('play', () => {
  document.querySelectorAll('audio').forEach(a => {
    if (a !== audio && !a.paused) a.pause();
  });
  setLive(true);
});

audio.addEventListener('pause', () => setLive(false));
audio.addEventListener('ended', () => setLive(false));



        // Refresh once if signed URL expires
        let refreshed=false;
        audio.addEventListener('error', async ()=>{
          if (refreshed){ pane.innerHTML='<div class="msg" style="color:#f66">Audio cannot be loaded</div>'; return; }
          refreshed=true;
          const r2 = await sign(r.track_path); if (r2.url) audio.src = r2.url;
        });
      }

      step.textContent = "Done";
    }catch(e){ stop("Fatal: " + (e?.message || e)); }
  }

  boot();
})();

